/* ══════════════ علامة — واجهة المستخدم ══════════════ */
"use strict";

var App = document.getElementById("app");

var S = {                      // حالة التطبيق
  categories: [],
  catBy: {},
  paragraphs: [],
  neuralTts: false,
  visionGrading: false,
  session: null,               // {role:'student'|'teacher', ...}
  drill: null,                 // جلسة الإملاء الجارية
  teacher: null                // بيانات لوحة المعلّم
};

/* ─────────────── أدوات عامة ─────────────── */

function esc(s) {
  return String(s == null ? "" : s)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function el(id) { return document.getElementById(id); }

function on(id, evt, fn) {
  var node = el(id);
  if (node) node.addEventListener(evt, fn);
}

function toast(msg, ms) {
  var old = document.querySelector(".toast");
  if (old) old.remove();
  var t = document.createElement("div");
  t.className = "toast";
  t.setAttribute("role", "status");
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(function () { if (t.parentNode) t.remove(); }, ms || 3400);
}

function render(html) {
  App.innerHTML = '<div class="screen">' + html + "</div>";
  // تمرير فوري لا ناعم: الناعم يبقى قيد التنفيذ بينما يستدعي التركيز
  // على أول حقل تمريرًا مضادًا، فتستقر الصفحة في منتصف الشاشة.
  window.scrollTo(0, 0);
}

function api(path, opts) {
  opts = opts || {};
  var init = { method: opts.method || "GET", credentials: "same-origin", headers: {} };
  if (opts.body !== undefined) {
    init.headers["Content-Type"] = "application/json";
    init.body = JSON.stringify(opts.body);
  }
  return fetch(path, init).then(function (r) {
    return r.json().catch(function () { return {}; }).then(function (data) {
      if (!r.ok) {
        var err = new Error(data.error || "تعذّر تنفيذ الطلب.");
        err.status = r.status;
        throw err;
      }
      return data;
    });
  });
}

/* نسبة -> تصنيف لوني موحّد في كل التطبيق */
function tier(rate) {
  if (rate === null || rate === undefined) return "none";
  if (rate >= 80) return "good";
  if (rate >= 50) return "mid";
  return "low";
}

function tierLabel(rate) {
  if (rate === null || rate === undefined) return "لا توجد بيانات بعد";
  var t = tier(rate);
  return t === "good" ? "متمكّن" : t === "mid" ? "يحتاج تدريبًا" : "يحتاج تركيزًا";
}

/* تمييز العدد في العربية: ١ مفرد، ٢ مثنى، ٣-١٠ جمع، ١١+ مفرد منصوب */
function countWord(n, one, two, few, many) {
  if (n === 1) return one;
  if (n === 2) return two;
  if (n >= 3 && n <= 10) return n + " " + few;
  return n + " " + many;
}

/* هذه الصيغ تأتي دائمًا بعد «من»، فالمثنى فيها مجرور: «محاولتين» لا «محاولتان» */
function attemptsText(n) {
  return countWord(n, "محاولة واحدة", "محاولتين", "محاولات", "محاولة");
}

function correctText(n) {
  return countWord(n, "صحيحة واحدة", "صحيحتان", "صحيحات", "صحيحة");
}

function wordsText(n) {
  return countWord(n, "كلمة واحدة", "كلمتين", "كلمات", "كلمة");
}

function catLabel(key) { return (S.catBy[key] || {}).label || key; }
function catRule(key) { return (S.catBy[key] || {}).rule || ""; }
function catColor(key) { return (S.catBy[key] || {}).color || "#DA74A3"; }

/* ─────────────── زهرة الجربيرا ─────────────── */

function gerbera(size, petal, core, ring) {
  var petals = "";
  for (var i = 0; i < 12; i++) {
    petals += '<ellipse cx="50" cy="26" rx="7.5" ry="20" fill="' + petal +
              '" transform="rotate(' + (i * 30) + ' 50 50)" opacity=".95"/>';
  }
  for (var j = 0; j < 12; j++) {
    petals += '<ellipse cx="50" cy="33" rx="5.5" ry="15" fill="' + petal +
              '" transform="rotate(' + (j * 30 + 15) + ' 50 50)" opacity=".75"/>';
  }
  return '<svg viewBox="0 0 100 100" width="' + size + '" height="' + size +
         '" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">' + petals +
         '<circle cx="50" cy="50" r="15" fill="' + core + '"/>' +
         '<circle cx="50" cy="50" r="9.5" fill="' + ring + '"/>' +
         '<circle cx="50" cy="50" r="4.5" fill="' + core + '"/></svg>';
}

function plantGarden() {
  var garden = el("garden");
  var palette = [
    ["#E9ACC8", "#F4D77A", "#DA74A3"],
    ["#BFD1F4", "#F8B553", "#94B2ED"],
    ["#DAE097", "#F4D77A", "#C9CE67"],
    ["#F8B553", "#DA74A3", "#F4D77A"]
  ];
  var spots = [
    [4, 8, 108], [86, 15, 74], [10, 62, 86], [78, 70, 120],
    [46, 88, 64], [92, 44, 58], [24, 33, 52], [64, 4, 66]
  ];
  var html = "";
  for (var i = 0; i < spots.length; i++) {
    var p = palette[i % palette.length];
    var s = spots[i];
    html += '<div class="bloom" style="left:' + s[0] + "%;top:" + s[1] +
            "%;animation-delay:" + (i * -1.9).toFixed(1) + "s;animation-duration:" +
            (12 + (i % 4) * 2.5) + 's">' + gerbera(s[2], p[0], p[1], p[2]) + "</div>";
  }
  garden.innerHTML = html;
}

/* ─────────────── الوجوه التعبيرية ─────────────── */

/* وجوه مرسومة بألوان اللوحة نفسها بدل إيموجي النظام —
   شكلها ثابت على كل جهاز ومتناغم مع بقية التصميم. */
function face(kind, size) {
  var skin = { cheer: "#F4D77A", happy: "#DAE097", think: "#BFD1F4",
               wow: "#E9ACC8" }[kind] || "#F4D77A";
  var ink = "#6D3A52";
  var eyes, mouth, extra = "";

  if (kind === "cheer") {                       // فرح كبير: عينان مغمضتان
    eyes = '<path d="M28 42 q7 -9 14 0" stroke="' + ink + '" stroke-width="4" ' +
           'fill="none" stroke-linecap="round"/>' +
           '<path d="M58 42 q7 -9 14 0" stroke="' + ink + '" stroke-width="4" ' +
           'fill="none" stroke-linecap="round"/>';
    mouth = '<path d="M32 58 q18 22 36 0 z" fill="' + ink + '"/>';
    extra = '<circle cx="20" cy="58" r="7" fill="#DA74A3" opacity=".5"/>' +
            '<circle cx="80" cy="58" r="7" fill="#DA74A3" opacity=".5"/>';
  } else if (kind === "happy") {                // ابتسامة هادئة
    eyes = '<circle cx="35" cy="43" r="5" fill="' + ink + '"/>' +
           '<circle cx="65" cy="43" r="5" fill="' + ink + '"/>';
    mouth = '<path d="M34 60 q16 16 32 0" stroke="' + ink + '" stroke-width="5" ' +
            'fill="none" stroke-linecap="round"/>';
  } else if (kind === "think") {                 // تشجيع: فم صغير وحاجب مائل
    eyes = '<circle cx="35" cy="45" r="5" fill="' + ink + '"/>' +
           '<circle cx="65" cy="45" r="5" fill="' + ink + '"/>' +
           '<path d="M27 33 q8 -5 16 -1" stroke="' + ink + '" stroke-width="3.5" ' +
           'fill="none" stroke-linecap="round"/>';
    mouth = '<path d="M38 64 q12 8 24 -2" stroke="' + ink + '" stroke-width="5" ' +
            'fill="none" stroke-linecap="round"/>';
  } else {                                        // wow: دهشة سعيدة
    eyes = '<circle cx="35" cy="42" r="6" fill="' + ink + '"/>' +
           '<circle cx="65" cy="42" r="6" fill="' + ink + '"/>';
    mouth = '<ellipse cx="50" cy="63" rx="10" ry="13" fill="' + ink + '"/>';
  }

  return '<svg viewBox="0 0 100 100" width="' + size + '" height="' + size +
    '" xmlns="http://www.w3.org/2000/svg" role="img" aria-hidden="true">' +
    '<circle cx="50" cy="50" r="46" fill="' + skin + '"/>' +
    '<circle cx="50" cy="50" r="46" fill="none" stroke="rgba(109,58,82,.16)" stroke-width="3"/>' +
    extra + eyes + mouth + "</svg>";
}

/* ─────────────── الكؤوس ─────────────── */

var TROPHY_ART = {
  bronze: { body: "#DD6B3A", shine: "#F8B553", name: "البرونزي" },
  silver: { body: "#94B2ED", shine: "#BFD1F4", name: "الفضي" },
  gold:   { body: "#F4D77A", shine: "#F8B553", name: "الذهبي" }
};

function trophy(kind, size, dim) {
  var c = TROPHY_ART[kind] || TROPHY_ART.gold;
  var body = dim ? "rgba(109,58,82,.14)" : c.body;
  var shine = dim ? "rgba(109,58,82,.08)" : c.shine;
  return '<svg viewBox="0 0 100 100" width="' + size + '" height="' + size +
    '" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">' +
    // العروتان
    '<path d="M26 26 h-9 a11 11 0 0 0 11 17" fill="none" stroke="' + body + '" stroke-width="6"/>' +
    '<path d="M74 26 h9 a11 11 0 0 1 -11 17" fill="none" stroke="' + body + '" stroke-width="6"/>' +
    // الكأس
    '<path d="M26 20 h48 v22 a24 24 0 0 1 -48 0 z" fill="' + body + '"/>' +
    '<path d="M36 26 h9 v14 a5 7 0 0 1 -9 0 z" fill="' + shine + '" opacity=".85"/>' +
    // الساق والقاعدة
    '<rect x="45" y="64" width="10" height="14" fill="' + body + '"/>' +
    '<rect x="31" y="78" width="38" height="9" rx="4" fill="' + body + '"/>' +
    "</svg>";
}

/* ─────────────── النطق ─────────────── */

var TTS = {
  audio: null,
  voice: null,

  pickVoice: function () {
    if (!("speechSynthesis" in window)) return;
    var voices = window.speechSynthesis.getVoices() || [];
    var arabic = voices.filter(function (v) { return /^ar/i.test(v.lang); });
    // يُفضَّل صوت محلي (أعلى جودة وبلا إنترنت) ثم أي صوت عربي.
    TTS.voice = arabic.filter(function (v) { return v.localService; })[0] ||
                arabic[0] || null;
  },

  stop: function () {
    if (TTS.audio) { TTS.audio.pause(); TTS.audio = null; }
    if ("speechSynthesis" in window) window.speechSynthesis.cancel();
  },

  /* يعيد وعدًا ينتهي عند انتهاء النطق. rate: 'normal' | 'slow' */
  speak: function (text, rate) {
    TTS.stop();
    if (S.neuralTts) {
      return fetch("/api/tts?rate=" + rate + "&text=" + encodeURIComponent(text),
                   { credentials: "same-origin" })
        .then(function (r) {
          if (!r.ok) throw new Error("neural unavailable");
          return r.blob();
        })
        .then(function (blob) {
          return new Promise(function (resolve) {
            var url = URL.createObjectURL(blob);
            TTS.audio = new Audio(url);
            TTS.audio.onended = TTS.audio.onerror = function () {
              URL.revokeObjectURL(url);
              resolve();
            };
            TTS.audio.play();
          });
        })
        .catch(function () { return TTS.browserSpeak(text, rate); });
    }
    return TTS.browserSpeak(text, rate);
  },

  browserSpeak: function (text, rate) {
    return new Promise(function (resolve) {
      if (!("speechSynthesis" in window)) {
        toast("متصفحك لا يدعم النطق الآلي.");
        return resolve();
      }
      if (!TTS.voice) TTS.pickVoice();
      var u = new SpeechSynthesisUtterance(text);
      u.lang = "ar-SA";
      u.rate = rate === "slow" ? 0.7 : 0.95;
      if (TTS.voice) u.voice = TTS.voice;
      u.onend = u.onerror = function () { resolve(); };
      window.speechSynthesis.speak(u);
      // بعض المتصفحات لا تطلق onend — صمّام أمان.
      setTimeout(resolve, Math.min(2000 + text.length * 260, 30000));
    });
  }
};

if ("speechSynthesis" in window) {
  TTS.pickVoice();
  window.speechSynthesis.onvoiceschanged = TTS.pickVoice;
}

/* زر النطق: يشغّل حالة "ينطق" بصريًا */
function bindSpeak(btnId, text, rate) {
  on(btnId, "click", function () {
    var b = el(btnId);
    b.classList.add("speaking");
    TTS.speak(text, rate || "normal").then(function () {
      if (b) b.classList.remove("speaking");
    });
  });
}

/* ═══════════════ شاشة الدخول ═══════════════ */

function screenLogin() {
  render(
    '<div class="brand">' +
      '<h1 class="wordmark">عَلَامَةٌ</h1>' +
      '<p class="tagline">خطوة بخطوة، نجعل كتابتكَ «علامةً» لا تُنسى</p>' +
    "</div>" +
    '<div class="card">' +
      '<h2 class="center">أهلاً بك</h2>' +
      '<p class="muted small center" style="margin-bottom:18px">' +
        "اكتب رقم المستخدم والرقم السري اللذين أعطتك إياهما معلّمتك.</p>" +
      '<form id="loginForm" class="stack" style="max-width:360px;margin:0 auto">' +
        '<label class="field"><span>رقم المستخدم</span>' +
          '<input id="fUser" class="pin" type="text" inputmode="numeric" ' +
                 'pattern="[0-9]*" maxlength="4" autocomplete="off" ' +
                 'placeholder="••••"></label>' +
        '<label class="field"><span>الرقم السري</span>' +
          '<input id="fSecret" class="pin" type="password" inputmode="numeric" ' +
                 'pattern="[0-9]*" maxlength="4" autocomplete="off" ' +
                 'placeholder="••••"></label>' +
        '<button class="btn primary lg block" type="submit">دخول ✿</button>' +
      "</form>" +
      '<p class="muted small center" style="margin:16px 0 0">' +
        "بعد أول دخول سيتذكّرك هذا الجهاز ولن تحتاج كتابتهما مرة أخرى.</p>" +
    "</div>" +
    '<div class="center">' +
      '<button class="btn ghost sm" id="toTeacher">أنا المعلّمة</button>' +
    "</div>"
  );

  var user = el("fUser"), secret = el("fSecret");
  user.focus({ preventScroll: true });

  function digitsOnly(node, thenFocus) {
    node.addEventListener("input", function (e) {
      e.target.value = e.target.value.replace(/\D/g, "").slice(0, 4);
      // ينتقل للحقل التالي وحده — أسهل لطفل يكتب على جوال.
      if (e.target.value.length === 4 && thenFocus) thenFocus();
    });
  }
  digitsOnly(user, function () { secret.focus({ preventScroll: true }); });
  digitsOnly(secret, function () { submitLogin(); });

  on("toTeacher", "click", function () { screenTeacherAuth("login"); });
  el("loginForm").addEventListener("submit", function (e) {
    e.preventDefault();
    submitLogin();
  });

  var busy = false;
  function submitLogin() {
    if (busy) return;
    if (user.value.length !== 4 || secret.value.length !== 4) {
      toast("رقم المستخدم والرقم السري: أربعة أرقام لكل منهما.");
      return;
    }
    busy = true;
    var btn = App.querySelector("button[type=submit]");
    btn.disabled = true;
    btn.textContent = "لحظة…";
    api("/api/student/login", {
      method: "POST",
      body: { username: user.value, secret: secret.value }
    }).then(function (state) {
      S.session = state;
      if (!state.student.diagnosticDone) screenDiagnosticIntro();
      else screenDashboard();
    }).catch(function (err) {
      busy = false;
      btn.disabled = false;
      btn.textContent = "دخول ✿";
      secret.value = "";
      secret.focus({ preventScroll: true });
      toast(err.message, 5000);
    });
  }
}

/* ═══════════════ دخول المعلّم ═══════════════ */

function screenTeacherAuth(mode) {
  var isLogin = mode !== "register";
  render(
    '<div class="brand" style="margin-bottom:14px">' +
      '<h1 class="wordmark mini">عَلَامَةٌ</h1>' +
      '<p class="tagline" style="margin-top:8px">لوحة المعلّمة</p>' +
    "</div>" +
    '<div class="card">' +
      "<h2>" + (isLogin ? "تسجيل دخول المعلّم" : "حساب معلّم جديد") + "</h2>" +
      '<form id="tForm" class="stack">' +
        (isLogin ? "" :
          '<label class="field"><span>الاسم</span>' +
          '<input id="tName" type="text" required placeholder="أ. سند"></label>') +
        '<label class="field"><span>البريد الإلكتروني</span>' +
          '<input id="tEmail" type="email" autocomplete="email" required></label>' +
        '<label class="field"><span>كلمة المرور' +
          (isLogin ? "" : ' <span class="muted small">(٨ أحرف فأكثر)</span>') + "</span>" +
          '<input id="tPass" type="password" autocomplete="' +
            (isLogin ? "current-password" : "new-password") + '" required></label>' +
        '<button class="btn sky lg block" type="submit">' +
          (isLogin ? "دخول" : "إنشاء الحساب") + "</button>" +
      "</form>" +
      '<hr class="divider">' +
      '<div class="center">' +
        '<button class="btn ghost sm" id="swap">' +
          (isLogin ? "ليس لديّ حساب — إنشاء حساب" : "لديّ حساب — تسجيل الدخول") + "</button>" +
      "</div>" +
    "</div>" +
    '<div class="center"><button class="btn ghost sm" id="backLogin">→ رجوع لدخول الطلاب</button></div>'
  );

  on("swap", "click", function () { screenTeacherAuth(isLogin ? "register" : "login"); });
  on("backLogin", "click", screenLogin);

  el("tForm").addEventListener("submit", function (e) {
    e.preventDefault();
    var btn = e.target.querySelector("button[type=submit]");
    btn.disabled = true;
    var body = { email: el("tEmail").value, password: el("tPass").value };
    if (!isLogin) body.name = el("tName").value;
    api(isLogin ? "/api/teacher/login" : "/api/teacher/register",
        { method: "POST", body: body })
      .then(function (data) {
        S.session = data;
        screenTeacherDashboard();
      })
      .catch(function (err) { btn.disabled = false; toast(err.message); });
  });
}

/* ═══════════════ الاختبار التشخيصي ═══════════════ */

function screenDiagnosticIntro() {
  render(
    '<div class="card center">' +
      '<div style="margin-bottom:6px">' + gerbera(90, "#F8B553", "#DA74A3", "#F4D77A") + "</div>" +
      "<h1>لنتعرّف على مستواك أولاً</h1>" +
      '<p>سأملي عليك <b>خمس كلمات</b> — واحدة من كل مسألة إملائية — ' +
        "ثم <b>جملة كاملة</b> تجمع المسائل الخمس معًا. " +
        "اكتب ما تسمعه بأفضل ما تستطيع، ولا بأس بالخطأ: هدف هذا الاختبار أن " +
        "أعرف أين تحتاج تدريبًا بالضبط.</p>" +
      '<div class="stack" style="max-width:420px;margin:20px auto 0;text-align:right">' +
        S.categories.map(function (c) {
          return '<div class="row" style="gap:9px;flex-wrap:nowrap">' +
                 '<i style="flex:0 0 auto;width:15px;height:15px;border-radius:50%;background:' +
                 c.color + '"></i><span class="small">' + esc(c.label) + "</span></div>";
        }).join("") +
      "</div>" +
      '<button class="btn primary lg" id="startDx" style="margin-top:22px">هيّا نبدأ ✿</button>' +
    "</div>"
  );
  on("startDx", "click", function () {
    api("/api/student/diagnostic").then(startDrill).catch(function (e) { toast(e.message); });
  });
}

/* ═══════════════ محرّك شاشة الإملاء ═══════════════ */

function startDrill(payload) {
  S.drill = { mode: payload.mode, items: payload.items, index: 0, results: [],
              sentence: payload.sentence || null };
  screenDrill();
}

function screenDrill() {
  var d = S.drill;
  var item = d.items[d.index];
  var isDx = d.mode === "diagnostic";

  var dots = d.items.map(function (_, i) {
    var cls = i < d.index ? (d.results[i] && d.results[i].correct ? "done" : "wrong")
                          : (i === d.index ? "current" : "");
    return "<i class='" + cls + "'></i>";
  }).join("");

  render(
    '<div class="card">' +
      '<div class="progress-dots">' + dots + "</div>" +
      '<p class="center muted small" style="margin-bottom:14px">' +
        "الكلمة " + (d.index + 1) + " من " + d.items.length +
        (isDx ? " · الاختبار التشخيصي" : " · تدريب اليوم") + "</p>" +

      '<p class="center">اضغط لسماع الكلمة، ثم اكتبها:</p>' +
      '<button class="speak-btn" id="speakBtn" aria-label="استمع للكلمة">🔊</button>' +
      '<div class="center" style="margin-bottom:18px">' +
        '<button class="btn ghost sm" id="slowBtn">🐢 أبطأ</button></div>' +

      '<form id="drillForm" class="stack">' +
        '<input id="answer" class="answer-box" type="text" autocomplete="off" ' +
               'autocorrect="off" autocapitalize="off" spellcheck="false" ' +
               'placeholder="اكتب الكلمة هنا" aria-label="إجابتك">' +
        '<button class="btn primary lg block" type="submit">تحقّق</button>' +
      "</form>" +
      '<p class="center muted small" style="margin:14px 0 0">' +
        "لا حاجة لكتابة الحركات — يكفي رسم الحروف صحيحًا.</p>" +
    "</div>"
  );

  bindSpeak("speakBtn", item.word, "normal");
  on("slowBtn", "click", function () { TTS.speak(item.word, "slow"); });

  el("answer").focus({ preventScroll: true });
  // نطق تلقائي عند ظهور الكلمة — بعد أول تفاعل من المستخدم يسمح المتصفح بذلك.
  setTimeout(function () {
    var b = el("speakBtn");
    if (!b) return;
    b.classList.add("speaking");
    TTS.speak(item.word, "normal").then(function () {
      var bb = el("speakBtn");
      if (bb) bb.classList.remove("speaking");
    });
  }, 380);

  el("drillForm").addEventListener("submit", function (e) {
    e.preventDefault();
    var answer = el("answer").value.trim();
    if (!answer) { toast("اكتب الكلمة أولاً، أو اسمعها مرة أخرى."); return; }
    var btn = e.target.querySelector("button[type=submit]");
    btn.disabled = true;
    TTS.stop();
    api("/api/student/attempt", {
      method: "POST",
      body: { word: item.word, category: item.category, answer: answer, mode: d.mode }
    }).then(function (res) {
      d.results.push(res);
      screenFeedback(res);
    }).catch(function (err) { btn.disabled = false; toast(err.message); });
  });
}

function screenFeedback(res) {
  var d = S.drill;
  var last = d.index === d.items.length - 1;

  render(
    '<div class="card">' +
      '<div class="verdict ' + (res.correct ? "right" : "wrong") + ' center">' +
        '<div style="margin-bottom:4px">' +
          face(res.correct ? "cheer" : "think", 96) + "</div>" +
        "<h2 style=\"margin:6px 0 12px\">" +
          (res.correct ? pickPraise() : "لا بأس — لنراجعها معًا") + "</h2>" +
        '<div class="word-compare">' + esc(res.expected) + "</div>" +
        (res.correct ? "" :
          '<div class="word-compare strike" style="font-size:1.4rem;margin-top:8px">' +
          esc(res.written) + "</div>" +
          '<p class="small muted" style="margin:10px 0 0">هكذا كتبتها</p>') +
      "</div>" +

      (res.correct ? "" :
        '<div class="rule-box">' +
          '<span class="label">' + esc(catLabel(res.category)) + "</span>" +
          esc(res.rule) +
        "</div>") +

      '<div class="center" style="margin-top:20px">' +
        '<button class="btn ' + (res.correct ? "mint" : "") + ' lg" id="nextBtn">' +
          (last ? "شاهد النتيجة ✿" : "الكلمة التالية ←") + "</button>" +
      "</div>" +
      '<div class="center" style="margin-top:10px">' +
        '<button class="btn ghost sm" id="hearAgain">🔊 اسمعها مرة أخرى</button></div>' +
    "</div>"
  );

  on("hearAgain", "click", function () { TTS.speak(res.expected, "slow"); });

  on("nextBtn", "click", function () {
    if (!last) { d.index++; screenDrill(); return; }
    if (d.mode === "diagnostic") {
      screenDiagnosticSentence();
    } else {
      var right = d.results.filter(function (r) { return r.correct; }).length;
      api("/api/student/practice/complete", {
        method: "POST",
        body: { kind: "adaptive", score: right, total: d.results.length }
      }).then(function (pr) {
        S.lastPractice = pr;
        return api("/api/student/state");
      }).then(function (state) {
        S.session = state;
        screenSessionResult();
      }).catch(function (e) { toast(e.message); });
    }
  });
}

/* عبارات تعزيز تتناوب حتى لا تُملّ الطالب بتكرار عبارة واحدة */
var PRAISE = ["أحسنت! كتابة صحيحة", "ممتاز! ضبطتها", "رائع — حرفًا حرفًا",
              "أصبت! إملاء سليم", "بارك الله فيك، صحيحة"];

function pickPraise() {
  return PRAISE[Math.floor(Math.random() * PRAISE.length)];
}

/* ═══════════════ شارة الدرجة ═══════════════ */

function scoreBadge(score, total) {
  var pct = total ? Math.round(100 * score / total) : 0;
  var t = tier(pct);
  var petal = t === "good" ? "#DAE097" : t === "mid" ? "#F4D77A" : "#E9ACC8";
  var core = t === "good" ? "#C9CE67" : t === "mid" ? "#F8B553" : "#DA74A3";
  return '<div class="score-badge">' + gerbera(210, petal, core, "#FAF3DE") +
         '<div class="value">' + score + "<small>من " + total + "</small></div></div>";
}

/* ═══════════════ جملة الاختبار التشخيصي ═══════════════ */

function screenDiagnosticSentence() {
  var sen = S.drill.sentence;
  if (!sen) return finishDiagnostic();
  var segments = sentencesOf(sen.text);

  render(
    '<div class="card">' +
      '<div class="center">' + face("happy", 76) + "</div>" +
      '<h2 class="center">والآن… جملة كاملة</h2>' +
      '<p class="center muted small">آخر خطوة في التشخيص. استمع للجملة ' +
        "واكتبها كما تسمعها. لا تكتب الحركات.</p>" +
      '<div class="center">' +
        '<button class="speak-btn" id="speakBtn" aria-label="استمع للجملة">🔊</button>' +
        '<div class="row" style="justify-content:center;margin-bottom:10px">' +
          '<button class="btn ghost sm" id="slowBtn">🐢 ببطء</button>' +
        "</div>" +
      "</div>" +
      (segments.length > 1 ?
        '<p class="center muted small">أو مقطعًا مقطعًا:</p>' +
        '<div class="row" style="justify-content:center;margin-bottom:16px">' +
          segments.map(function (_, i) {
            return '<button class="btn sm mint" data-s="' + i + '">مقطع ' + (i + 1) + "</button>";
          }).join("") + "</div>" : "") +
      '<label class="field"><span>اكتب الجملة</span>' +
        '<textarea id="sentenceBox" placeholder="اكتب ما تسمعه هنا…" ' +
                  'autocorrect="off" spellcheck="false"></textarea></label>' +
      '<button class="btn primary lg block" id="sendSentence" style="margin-top:14px">' +
        "أنهيت — أرني نتيجتي</button>" +
    "</div>"
  );

  bindSpeak("speakBtn", sen.text, "normal");
  on("slowBtn", "click", function () { TTS.speak(sen.text, "slow"); });
  Array.prototype.forEach.call(App.querySelectorAll("[data-s]"), function (b) {
    b.addEventListener("click", function () { TTS.speak(segments[+b.dataset.s], "slow"); });
  });

  on("sendSentence", "click", function () {
    var answer = el("sentenceBox").value.trim();
    if (!answer) { toast("اكتب الجملة أولاً، أو اسمعها مرة أخرى."); return; }
    TTS.stop();
    el("sendSentence").disabled = true;
    api("/api/student/diagnostic/sentence", {
      method: "POST", body: { answer: answer }
    }).then(function (res) {
      S.drill.sentenceResult = res;
      finishDiagnostic();
    }).catch(function (e) {
      el("sendSentence").disabled = false;
      toast(e.message);
    });
  });
}

function finishDiagnostic() {
  api("/api/student/diagnostic/finish", { method: "POST" })
    .then(function (state) { S.session = state; screenDiagnosticReport(); })
    .catch(function (e) { toast(e.message); });
}

/* ═══════════════ تقرير التشخيص ═══════════════ */

function masteryRow(m) {
  var rate = m.rate;
  var t = tier(rate);
  var width = rate === null || rate === undefined ? 0 : rate;
  return '<div class="mastery-row">' +
    '<div class="between">' +
      '<span class="name">' + (m.mastered ? "✅ " : "") + esc(catLabel(m.category)) + "</span>" +
      '<span class="badge ' + (t === "none" ? "" : t) + '">' +
        (rate === null || rate === undefined ? "—" : rate + "٪") + "</span>" +
    "</div>" +
    '<div class="bar"><i class="' + (t === "none" ? "" : t) + '" style="width:' +
      width + '%;background:' + (t === "none" ? "transparent" : "") + '"></i></div>' +
    '<p class="small muted" style="margin:6px 0 0">' +
      // الإتقان يُقاس بآخر ٥ محاولات، والنسبة تراكمية منذ البداية —
      // فنقول ذلك صراحة بدل «يحتاج تدريبًا» بجوار علامة ✅.
      (m.mastered ? "مُتقن — آخر خمس محاولات كلها صحيحة" : tierLabel(rate)) +
      (m.attempts ? " · " + correctText(m.correct) + " من " + attemptsText(m.attempts) : "") +
    "</p></div>";
}

function screenDiagnosticReport() {
  var mastery = S.session.mastery;
  var sr = (S.drill || {}).sentenceResult;
  var correct = mastery.reduce(function (a, m) { return a + m.correct; }, 0);
  var total = mastery.reduce(function (a, m) { return a + m.attempts; }, 0);
  var weakest = mastery[0];

  render(
    '<div class="card center">' +
      '<div style="margin-bottom:2px">' + face("happy", 76) + "</div>" +
      "<h1>خريطة أخطائك</h1>" +
      scoreBadge(correct, total) +
      '<p class="muted">هذه صورة مستواك الآن — وسنعمل على تحسينها معًا.</p>' +
    "</div>" +

    (sr ?
      '<div class="card">' +
        "<h2>جملتك</h2>" +
        '<p class="muted small" style="margin-top:-6px">' +
          "أصبتَ " + wordsText(sr.score) + " من " + sr.total + "</p>" +
        '<div class="paragraph-text" style="font-size:1.15rem;line-height:2.2">' +
          sr.items.map(function (it) {
            return it.is_correct
              ? '<span>' + esc(it.correct_text) + "</span> "
              : '<span class="miss">' + esc(it.correct_text) + "</span> ";
          }).join("") +
        "</div>" +
        (sr.items.filter(function (i) { return !i.is_correct; }).length ?
          '<p class="small muted" style="margin:12px 0 0">' +
            "الكلمات الملوّنة هي التي اختلفت عمّا كتبت.</p>" : "") +
      "</div>" : "") +

    '<div class="card">' +
      "<h2>الموضوعات من الأضعف إلى الأقوى</h2>" +
      '<div class="mastery">' + mastery.map(masteryRow).join("") + "</div>" +
    "</div>" +

    (weakest && weakest.rate !== null ?
      '<div class="card">' +
        '<h3>سنبدأ من هنا: ' + esc(catLabel(weakest.category)) + "</h3>" +
        '<div class="rule-box" style="margin-top:6px">' +
          '<span class="label">القاعدة</span>' + esc(catRule(weakest.category)) +
        "</div></div>" : "") +

    '<div class="center">' +
      '<button class="btn primary lg" id="toDash">إلى لوحتي ✿</button></div>'
  );

  on("toDash", "click", screenDashboard);
}

/* ═══════════════ الكؤوس والمهمة الأسبوعية ═══════════════ */

function trophyShelf(tr) {
  var catalog = S.session.trophyCatalog || [];
  var shelf = catalog.map(function (t) {
    var won = tr.earned.indexOf(t.key) >= 0;
    return '<div class="trophy-slot' + (won ? " won" : "") + '">' +
availableTrophy(t, won) +
      '<div class="small" style="font-weight:700">' + esc(t.label) + "</div>" +
      '<div class="small muted">' + t.needed + " تدريبًا</div>" +
    "</div>";
  }).join("");

  var next = tr.next;
  return '<div class="card">' +
    '<div class="between" style="margin-bottom:14px">' +
      "<h2 style=\"margin:0\">كؤوسك</h2>" +
      '<span class="chip">' + tr.sessionsDone + " تدريبًا</span>" +
    "</div>" +
    '<div class="trophy-shelf">' + shelf + "</div>" +
    (next ?
      '<div style="margin-top:16px">' +
        '<div class="between" style="margin-bottom:6px">' +
          '<span class="small">نحو ' + esc(next.label) + "</span>" +
          '<span class="small muted">باقٍ ' +
            countWord(next.remaining, "تدريب واحد", "تدريبان", "تدريبات", "تدريبًا") +
          "</span>" +
        "</div>" +
        '<div class="bar"><i class="good" style="width:' + next.progress + '%"></i></div>' +
      "</div>" :
      '<p class="center" style="margin:16px 0 0;font-weight:700">' +
        "جمعتَ الكؤوس الثلاثة كلها! ✿</p>") +
  "</div>";
}

function availableTrophy(t, won) {
  return trophy(t.key, 64, !won);
}

function weeklyCard(w) {
  return '<div class="card' + (w.complete ? " week-done" : "") + '">' +
    '<div class="row" style="gap:14px;flex-wrap:nowrap;align-items:flex-start">' +
      '<div style="flex:0 0 auto">' + face(w.complete ? "cheer" : "happy", 58) + "</div>" +
      '<div class="grow">' +
        '<div class="between" style="margin-bottom:6px">' +
          "<h3 style=\"margin:0\">مهمة هذا الأسبوع</h3>" +
          // «5 / 3» يربك القراءة في اتجاه اليمين لليسار، فنقيّد المعروض
          // بالهدف ونذكر الزائد في النص أسفله.
          '<span class="chip">' + Math.min(w.done, w.goal) + " / " + w.goal +
            (w.done > w.goal ? " ✿" : "") + "</span>" +
        "</div>" +
        '<div class="bar"><i class="' + (w.complete ? "good" : "mid") +
          '" style="width:' + w.progress + '%"></i></div>' +
        '<p class="small muted" style="margin:8px 0 0">' +
          (w.complete
            ? (w.done > w.goal
                ? "أنجزت مهمة الأسبوع، وزدتَ عليها " +
                  countWord(w.done - w.goal, "تدريبًا واحدًا", "تدريبين",
                            "تدريبات", "تدريبًا") + " — أحسنت!"
                : "أنجزت مهمة الأسبوع كاملة — أحسنت!")
            : "أنجز " + countWord(w.remaining, "تدريبًا واحدًا", "تدريبين",
                                  "تدريبات", "تدريبًا") +
              " قبل نهاية الأسبوع.") +
        "</p>" +
      "</div>" +
    "</div>" +
  "</div>";
}

/* الشهادات التي استحقّها الطالب: كأس لكل عتبة، وشهادة لكل مسألة أتقنها */
function certificates() {
  var out = [];
  var tr = S.session.trophies || { earned: [] };
  (S.session.trophyCatalog || []).forEach(function (t) {
    if (tr.earned.indexOf(t.key) >= 0) {
      out.push({ kind: "trophy", key: t.key, title: "شهادة " + t.label });
    }
  });
  (S.session.mastery || []).forEach(function (m) {
    if (m.mastered) {
      out.push({ kind: "mastery", key: m.category,
                 title: "شهادة إتقان: " + catLabel(m.category) });
    }
  });
  return out;
}

/* ═══════════════ شهادة التميّز ═══════════════ */

function screenCertificate(kind, key, back) {
  var st = S.session.student;
  var title, subtitle, art;
  if (kind === "trophy") {
    var t = (S.session.trophyCatalog || []).filter(function (x) {
      return x.key === key; })[0] || { label: "كأس", needed: "" };
    title = "شهادة " + t.label;
    subtitle = "لإنجازه " + t.needed + " تدريبًا إملائيًا";
    art = trophy(key, 130);
  } else {
    title = "شهادة إتقان";
    subtitle = "لإتقانه مسألة: " + catLabel(key);
    art = gerbera(130, "#DAE097", "#C9CE67", "#FAF3DE");
  }

  var today = new Date().toLocaleDateString("ar", {
    year: "numeric", month: "long", day: "numeric" });

  render(
    '<div class="certificate" id="cert">' +
      '<div class="cert-corner tl">' + gerbera(50, "#E9ACC8", "#F4D77A", "#DA74A3") + "</div>" +
      '<div class="cert-corner tr">' + gerbera(50, "#BFD1F4", "#F8B553", "#94B2ED") + "</div>" +
      '<div class="cert-corner bl">' + gerbera(50, "#DAE097", "#F4D77A", "#C9CE67") + "</div>" +
      '<div class="cert-corner br">' + gerbera(50, "#F8B553", "#DA74A3", "#F4D77A") + "</div>" +
      '<p class="cert-kicker">شهادة تميّز</p>' +
      '<p class="cert-brand">عَلَامَةٌ</p>' +
      '<h1 class="cert-title">' + esc(title) + "</h1>" +
      '<p class="cert-line">تُمنح هذه الشهادة للطالب</p>' +
      '<p class="cert-name">' + esc(st.name) + "</p>" +
      '<div class="cert-art">' + art + "</div>" +
      '<p class="cert-line">' + esc(subtitle) + "</p>" +
      '<div class="cert-foot">' +
        "<span>" + (st.teacherName ? "المعلّمة: " + esc(st.teacherName) : "") + "</span>" +
        "<span>" + esc(today) + "</span>" +
      "</div>" +
    "</div>" +
    '<div class="row no-print" style="justify-content:center;margin-top:6px">' +
      '<button class="btn mint" id="printCert">🖨️ اطبعها أو احفظها</button>' +
      '<button class="btn ghost" id="certBack">رجوع</button>' +
    "</div>"
  );

  on("printCert", "click", function () { window.print(); });
  on("certBack", "click", back || screenDashboard);
}

/* ═══════════════ لوحة الطالب ═══════════════ */

function screenDashboard() {
  var st = S.session.student;
  var mastery = S.session.mastery;
  var mastered = mastery.filter(function (m) { return m.mastered; }).length;
  var rated = mastery.filter(function (m) { return m.rate !== null; });
  var avg = rated.length
    ? Math.round(rated.reduce(function (a, m) { return a + m.rate; }, 0) / rated.length)
    : null;
  var allMastered = mastered === mastery.length;

  render(
    '<div class="between" style="margin-bottom:18px">' +
      "<div><h1 style=\"margin:0\">أهلاً " + esc(st.name) + " ✿</h1>" +
      '<p class="muted small" style="margin:2px 0 0">' +
        (st.teacherName ? "صف " + esc(st.teacherName) : "لم تنضم لصف بعد") + "</p></div>" +
      '<button class="btn ghost sm" id="logout">خروج</button>' +
    "</div>" +

    (allMastered ?
      '<div class="card center" style="background:var(--pistachio)">' +
        gerbera(84, "#FFFCF2", "#C9CE67", "#FAF3DE") +
        "<h2>أتقنتَ الموضوعات الخمسة كلها!</h2>" +
        '<p class="small">نسبة الخطأ صفر في كل الموضوعات. واصل التدريب من حين لآخر ' +
        "حتى لا تتراجع المهارة.</p></div>" : "") +

    '<div class="card">' +
      '<div class="between" style="margin-bottom:16px">' +
        "<h2 style=\"margin:0\">خريطة إتقانك</h2>" +
        '<span class="chip">' + mastered + " من " + mastery.length + " مُتقن</span>" +
      "</div>" +
      '<div class="mastery">' + mastery.map(masteryRow).join("") + "</div>" +
      (avg !== null ? '<p class="center muted small" style="margin:18px 0 0">' +
        "متوسط إتقانك العام: <b>" + avg + "٪</b></p>" : "") +
    "</div>" +

    weeklyCard(S.session.weekly) +
    trophyShelf(S.session.trophies) +

    (certificates().length ?
      '<div class="card">' +
        "<h2>شهاداتك</h2>" +
        '<div class="stack">' + certificates().map(function (c) {
          return '<button class="btn sky block sm" data-cert="' + c.kind + ':' +
                 esc(c.key) + '">📜 ' + esc(c.title) + "</button>";
        }).join("") + "</div>" +
      "</div>" : "") +

    '<div class="card stack">' +
      "<h2 style=\"margin:0 0 4px\">ماذا تريد أن تفعل؟</h2>" +
      '<button class="btn primary lg block" id="startPractice">' +
        "✿ ابدأ جلسة تدريب اليوم</button>" +
      '<p class="muted small center" style="margin:-4px 0 6px">' +
        "٦ كلمات مختارة خصيصًا لك، أكثرها من موضوعاتك الأضعف.</p>" +
      '<button class="btn sky block" id="startParagraph">✎ تمرين فقرة كاملة</button>' +
    "</div>"
  );

  on("logout", "click", function () {
    api("/api/logout", { method: "POST" }).then(function () {
      S.session = null;
      screenLogin();
    });
  });

  Array.prototype.forEach.call(App.querySelectorAll("[data-cert]"), function (b) {
    b.addEventListener("click", function () {
      var parts = b.dataset.cert.split(":");
      screenCertificate(parts[0], parts.slice(1).join(":"));
    });
  });

  on("startPractice", "click", function () {
    api("/api/student/session").then(startDrill).catch(function (e) { toast(e.message); });
  });

  on("startParagraph", "click", screenParagraphPick);

}

/* ═══════════════ نتيجة جلسة التدريب ═══════════════ */

function screenSessionResult() {
  var d = S.drill;
  var correct = d.results.filter(function (r) { return r.correct; }).length;
  var wrong = d.results.filter(function (r) { return !r.correct; });

  // القواعد العلاجية مرة واحدة لكل موضوع أخطأ فيه الطالب.
  var seen = {};
  var rules = [];
  wrong.forEach(function (r) {
    if (seen[r.category]) return;
    seen[r.category] = true;
    rules.push(r);
  });

  var pr = S.lastPractice || { newTrophies: [] };
  var mastered = [];
  d.results.forEach(function (r) {
    if (r.justMastered && mastered.indexOf(r.justMastered) < 0) {
      mastered.push(r.justMastered);
    }
  });
  var perfect = correct === d.results.length;

  render(
    '<div class="card center">' +
      '<div style="margin-bottom:2px">' +
        face(perfect ? "cheer" : (correct >= d.results.length / 2 ? "happy" : "think"), 84) +
      "</div>" +
      "<h1>" + (perfect ? "جلسة كاملة بلا خطأ!" : "أحسنت، انتهت الجلسة") + "</h1>" +
      scoreBadge(correct, d.results.length) +
    "</div>" +

    (pr.newTrophies && pr.newTrophies.length ?
      pr.newTrophies.map(function (k) {
        var t = (S.session.trophyCatalog || []).filter(function (x) {
          return x.key === k; })[0] || { label: "كأس" };
        return '<div class="card center celebrate">' +
          trophy(k, 110) +
          "<h2 style=\"margin:10px 0 4px\">حصلتَ على " + esc(t.label) + "!</h2>" +
          '<p class="muted small">إنجاز يستحق شهادة.</p>' +
          '<button class="btn primary" data-cert="trophy:' + esc(k) + '">' +
            "📜 استلم شهادتك</button>" +
        "</div>";
      }).join("") : "") +

    (mastered.length ?
      mastered.map(function (c) {
        return '<div class="card center celebrate">' +
          gerbera(84, "#DAE097", "#C9CE67", "#FAF3DE") +
          "<h2 style=\"margin:10px 0 4px\">أتقنتَ مسألة جديدة!</h2>" +
          "<p><b>" + esc(catLabel(c)) + "</b></p>" +
          '<button class="btn primary" data-cert="mastery:' + esc(c) + '">' +
            "📜 استلم شهادتك</button>" +
        "</div>";
      }).join("") : "") +

    (wrong.length ?
      '<div class="card">' +
        "<h2>كلمات نراجعها</h2>" +
        '<div class="stack">' + wrong.map(function (r) {
          return '<div style="border-bottom:2px solid var(--line);padding-bottom:12px">' +
            '<div class="row" style="gap:14px">' +
              '<span class="word-compare" style="font-size:1.5rem">' + esc(r.expected) + "</span>" +
              '<span class="word-compare strike" style="font-size:1.15rem">' + esc(r.written) + "</span>" +
            "</div>" +
            '<p class="small muted" style="margin:4px 0 0">' + esc(catLabel(r.category)) + "</p>" +
          "</div>";
        }).join("") + "</div>" +
      "</div>" : "") +

    (rules.length ?
      '<div class="card"><h2>القواعد التي تحتاجها</h2><div class="stack">' +
        rules.map(function (r) {
          return '<div class="rule-box"><span class="label">' +
                 esc(catLabel(r.category)) + "</span>" + esc(r.rule) + "</div>";
        }).join("") + "</div></div>" : "") +

    '<div class="row" style="justify-content:center">' +
      '<button class="btn primary lg" id="again">جلسة أخرى ✿</button>' +
      '<button class="btn ghost" id="toDash">لوحتي</button>' +
    "</div>"
  );

  Array.prototype.forEach.call(App.querySelectorAll("[data-cert]"), function (b) {
    b.addEventListener("click", function () {
      var parts = b.dataset.cert.split(":");
      screenCertificate(parts[0], parts.slice(1).join(":"), screenSessionResult);
    });
  });

  on("again", "click", function () {
    api("/api/student/session").then(startDrill).catch(function (e) { toast(e.message); });
  });
  on("toDash", "click", screenDashboard);
}

/* ═══════════════ تمرين الفقرة ═══════════════ */

function screenParagraphPick() {
  render(
    '<div class="between" style="margin-bottom:16px">' +
      "<h1 style=\"margin:0\">تمرين فقرة كاملة</h1>" +
      '<button class="btn ghost sm" id="back">→ لوحتي</button>' +
    "</div>" +
    '<div class="card stack">' +
      "<h2 style=\"margin:0\">اختر فقرة</h2>" +
      S.paragraphs.map(function (p) {
        return '<button class="btn sky block" data-para="' + esc(p.id) + '">' +
               esc(p.title) + "</button>";
      }).join("") +
    "</div>"
  );
  on("back", "click", screenDashboard);
  Array.prototype.forEach.call(App.querySelectorAll("[data-para]"), function (b) {
    b.addEventListener("click", function () { screenParagraphMode(b.dataset.para); });
  });
}

function paragraphById(id) {
  return S.paragraphs.filter(function (p) { return p.id === id; })[0];
}

function screenParagraphMode(id) {
  var p = paragraphById(id);
  render(
    '<div class="between" style="margin-bottom:16px">' +
      "<h1 style=\"margin:0\">" + esc(p.title) + "</h1>" +
      '<button class="btn ghost sm" id="back">→ رجوع</button>' +
    "</div>" +
    '<div class="card stack">' +
      "<h2 style=\"margin:0\">كيف تريد أن تكتب؟</h2>" +
      '<button class="btn primary block lg" id="mKeyboard">⌨️ الكتابة بلوحة المفاتيح</button>' +
      '<button class="btn peony block lg" id="mPhoto">📷 أكتب في دفتري ثم أصوّرها</button>' +
      (S.visionGrading ? "" :
        '<div class="notice small">تصحيح الصور غير مفعّل على هذا الخادم. ' +
        "لتفعيله شغّل الخادم بمفتاح <code>ANTHROPIC_API_KEY</code>.</div>") +
    "</div>"
  );
  on("back", "click", screenParagraphPick);
  on("mKeyboard", "click", function () { screenParagraphType(id); });
  on("mPhoto", "click", function () { screenParagraphPhoto(id); });
}

/* تُقسَّم الفقرة إلى مقاطع قصيرة ليلحق بها الطالب في الكتابة.
   نتجنّب lookbehind في التعبير النمطي عمدًا: لا تدعمه متصفحات Safari
   الأقدم من 16.4، ووجوده في ملف الكود يمنع تشغيل التطبيق كله عليها. */
function sentencesOf(text) {
  var parts = text.match(/[^.؟!،]+[.؟!،]*/g) || [];
  var out = [];
  for (var i = 0; i < parts.length; i++) {
    var piece = parts[i].trim();
    if (piece.length > 1) out.push(piece);
  }
  return out.length ? out : [text];
}

function screenParagraphType(id) {
  var p = paragraphById(id);
  var sentences = sentencesOf(p.text);

  render(
    '<div class="between" style="margin-bottom:16px">' +
      "<h1 style=\"margin:0\">" + esc(p.title) + "</h1>" +
      '<button class="btn ghost sm" id="back">→ رجوع</button>' +
    "</div>" +
    '<div class="card">' +
      '<div class="center">' +
        '<button class="speak-btn" id="speakBtn" aria-label="استمع للفقرة">🔊</button>' +
        '<div class="row" style="justify-content:center;margin-bottom:6px">' +
          '<button class="btn ghost sm" id="slowBtn">🐢 الفقرة كاملة ببطء</button>' +
        "</div>" +
      "</div>" +
      '<p class="center muted small">أو استمع مقطعًا مقطعًا:</p>' +
      '<div class="row" style="justify-content:center;margin-bottom:18px">' +
        sentences.map(function (_, i) {
          return '<button class="btn sm mint" data-s="' + i + '">مقطع ' + (i + 1) + "</button>";
        }).join("") +
      "</div>" +
      '<label class="field"><span>اكتب ما تسمعه</span>' +
        '<textarea id="para" placeholder="اكتب الفقرة هنا…" ' +
                  'autocorrect="off" spellcheck="false"></textarea></label>' +
      '<button class="btn primary lg block" id="submitPara" style="margin-top:14px">صحّح إملائي</button>' +
    "</div>"
  );

  on("back", "click", function () { screenParagraphMode(id); });
  bindSpeak("speakBtn", p.text, "normal");
  on("slowBtn", "click", function () { TTS.speak(p.text, "slow"); });
  Array.prototype.forEach.call(App.querySelectorAll("[data-s]"), function (b) {
    b.addEventListener("click", function () {
      TTS.speak(sentences[+b.dataset.s], "slow");
    });
  });

  on("submitPara", "click", function () {
    var answer = el("para").value.trim();
    if (!answer) { toast("اكتب الفقرة أولاً."); return; }
    TTS.stop();
    el("submitPara").disabled = true;
    api("/api/paragraph/grade-text", {
      method: "POST", body: { paragraphId: id, answer: answer }
    }).then(function (res) { screenParagraphResult(id, res); })
      .catch(function (e) { el("submitPara").disabled = false; toast(e.message); });
  });
}

function screenParagraphPhoto(id) {
  var p = paragraphById(id);
  render(
    '<div class="between" style="margin-bottom:16px">' +
      "<h1 style=\"margin:0\">" + esc(p.title) + "</h1>" +
      '<button class="btn ghost sm" id="back">→ رجوع</button>' +
    "</div>" +
    '<div class="card">' +
      '<p class="center">استمع للفقرة، اكتبها في دفترك بخط واضح، ثم صوّر الورقة.</p>' +
      '<div class="center">' +
        '<button class="speak-btn" id="speakBtn" aria-label="استمع للفقرة">🔊</button>' +
        '<div class="row" style="justify-content:center;margin-bottom:16px">' +
          '<button class="btn ghost sm" id="slowBtn">🐢 ببطء</button></div>' +
      "</div>" +
      '<label class="field"><span>صورة الورقة</span>' +
        '<input id="photo" type="file" accept="image/*" capture="environment"></label>' +
      '<div id="preview" style="margin-top:14px"></div>' +
      '<button class="btn primary lg block" id="sendPhoto" style="margin-top:14px" disabled>' +
        "صحّح من الصورة</button>" +
      '<div class="notice small" style="margin-top:14px">' +
        "<b>انتبه:</b> قراءة خط اليد آليًا ليست معصومة من الخطأ، خصوصًا مع خطوط الأطفال. " +
        "اعتبر هذا التصحيح مساعدًا لك، وراجع النتيجة مع معلّمك عند الشك.</div>" +
    "</div>"
  );

  on("back", "click", function () { screenParagraphMode(id); });
  bindSpeak("speakBtn", p.text, "normal");
  on("slowBtn", "click", function () { TTS.speak(p.text, "slow"); });

  var dataUrl = null;
  el("photo").addEventListener("change", function (e) {
    var file = e.target.files && e.target.files[0];
    if (!file) return;
    if (file.size > 10 * 1024 * 1024) {
      toast("الصورة كبيرة جدًا — جرّب صورة أصغر.");
      return;
    }
    var reader = new FileReader();
    reader.onload = function () {
      dataUrl = reader.result;
      el("preview").innerHTML = '<img class="photo-preview" src="' + dataUrl + '" alt="معاينة الصورة">';
      el("sendPhoto").disabled = false;
    };
    reader.readAsDataURL(file);
  });

  on("sendPhoto", "click", function () {
    if (!dataUrl) return;
    TTS.stop();
    render('<div class="card center"><h2>أقرأ خطّك الآن…</h2>' +
           '<div class="spinner"></div>' +
           '<p class="muted small">قد يستغرق هذا نصف دقيقة.</p></div>');
    api("/api/paragraph/grade-image", {
      method: "POST", body: { paragraphId: id, image: dataUrl }
    }).then(function (res) { screenParagraphResult(id, res); })
      .catch(function (e) {
        toast(e.message, 6000);
        screenParagraphPhoto(id);
      });
  });
}

function screenParagraphResult(id, res) {
  // تمرين الفقرة يُحتسب تدريبًا كجلسة الكلمات — نسجّله ثم نعرض النتيجة.
  if (!res._recorded) {
    res._recorded = true;
    return api("/api/student/practice/complete", {
      method: "POST",
      body: { kind: "paragraph", score: res.score || 0,
              total: res.total || (res.items || []).length }
    }).then(function (pr) {
      S.lastPractice = pr;
      return api("/api/student/state");
    }).then(function (state) {
      S.session = state;
      screenParagraphResult(id, res);
    }).catch(function () {
      screenParagraphResult(id, res);      // النتيجة أهم من عدّاد التدريبات
    });
  }

  var items = res.items || [];
  var score = res.score != null ? res.score : 0;
  var total = res.total || items.length;
  var wrong = items.filter(function (it) { return !it.is_correct; });
  var newT = (S.lastPractice || {}).newTrophies || [];

  render(
    '<div class="card center">' +
      '<div style="margin-bottom:2px">' +
        face(score === total ? "cheer" : (score >= total / 2 ? "happy" : "think"), 76) +
      "</div>" +
      "<h1>نتيجة الفقرة</h1>" +
      scoreBadge(score, total) +
      '<p class="muted small">' +
        (res.source === "image" ? "قراءة آلية لخط اليد — قد تخطئ أحيانًا"
                                : "كلمة بكلمة، بعد تجاهل الحركات") + "</p>" +
      (res.overall_feedback ? "<p>" + esc(res.overall_feedback) + "</p>" : "") +
    "</div>" +

    '<div class="card">' +
      "<h2>النص الصحيح</h2>" +
      '<div class="paragraph-text">' + esc(res.expected) + "</div>" +
    "</div>" +

    (wrong.length ?
      '<div class="card"><h2>كلمات تحتاج مراجعة</h2><div class="stack">' +
        wrong.map(function (it) {
          return '<div style="border-bottom:2px solid var(--line);padding-bottom:10px">' +
            '<div class="row" style="gap:14px">' +
              '<span style="font-size:1.35rem;font-weight:700">' + esc(it.correct_text) + "</span>" +
              '<span class="strike" style="font-size:1.1rem">' +
                esc(it.written_text || "— لم تُكتب —") + "</span>" +
            "</div>" +
            (it.note ? '<p class="small muted" style="margin:4px 0 0">' + esc(it.note) + "</p>" : "") +
          "</div>";
        }).join("") + "</div></div>" :
      '<div class="card center"><h2>لا أخطاء ✿</h2>' +
      '<p class="muted">كتابة سليمة من أولها إلى آخرها.</p></div>') +

    ((res.extra_words && res.extra_words.length) ?
      '<div class="card"><h3>كلمات زائدة عن النص</h3><p>' +
      esc(res.extra_words.join("، ")) + "</p></div>" : "") +

    (newT.length ? newT.map(function (k) {
      var t = (S.session.trophyCatalog || []).filter(function (x) {
        return x.key === k; })[0] || { label: "كأس" };
      return '<div class="card center celebrate">' + trophy(k, 110) +
        "<h2 style=\"margin:10px 0 4px\">حصلتَ على " + esc(t.label) + "!</h2>" +
        '<button class="btn primary" data-cert="trophy:' + esc(k) + '">' +
          "📜 استلم شهادتك</button></div>";
    }).join("") : "") +

    '<div class="row" style="justify-content:center">' +
      '<button class="btn primary" id="retry">أعِد المحاولة</button>' +
      '<button class="btn ghost" id="toDash">لوحتي</button>' +
    "</div>"
  );

  Array.prototype.forEach.call(App.querySelectorAll("[data-cert]"), function (b) {
    b.addEventListener("click", function () {
      var parts = b.dataset.cert.split(":");
      screenCertificate(parts[0], parts.slice(1).join(":"), screenDashboard);
    });
  });

  on("retry", "click", function () { screenParagraphMode(id); });
  on("toDash", "click", screenDashboard);
}

/* ═══════════════ لوحة المعلّمة ═══════════════ */

function screenTeacherDashboard() {
  render('<div class="card center"><div class="spinner"></div></div>');
  api("/api/teacher/overview").then(function (data) {
    S.teacher = data;
    renderTeacherDashboard(data);
  }).catch(function (e) {
    toast(e.message);
    screenTeacherAuth("login");
  });
}

function lastSeenText(ts) {
  if (!ts) return "لم يدخل بعد";
  var mins = Math.round((Date.now() / 1000 - ts) / 60);
  if (mins < 2) return "الآن";
  if (mins < 60) return "قبل " + mins + " دقيقة";
  var hrs = Math.round(mins / 60);
  if (hrs < 24) return countWord(hrs, "قبل ساعة", "قبل ساعتين", "قبل ساعات", "قبل ساعة");
  var days = Math.round(hrs / 24);
  return countWord(days, "أمس", "قبل يومين", "قبل أيام", "قبل يوم");
}

function renderTeacherDashboard(data) {
  var students = data.students;
  var averages = data.classAverages;
  var weakest = averages.filter(function (a) { return a.rate !== null; })[0];

  render(
    '<div class="between" style="margin-bottom:18px">' +
      "<div><h1 style=\"margin:0\">" + esc(data.teacher.name) + "</h1>" +
      '<p class="muted small" style="margin:2px 0 0">لوحة متابعة الصف</p></div>' +
      '<button class="btn ghost sm" id="logout">خروج</button>' +
    "</div>" +

    '<div class="card">' +
      '<div class="between" style="margin-bottom:14px">' +
        "<h2 style=\"margin:0\">قائمة الصف</h2>" +
        '<span class="chip">' +
          countWord(students.length, "طالب واحد", "طالبان", "طلاب", "طالبًا") + "</span>" +
      "</div>" +
      '<form id="addForm" class="row" style="gap:10px;margin-bottom:18px">' +
        '<input id="newName" type="text" class="grow" placeholder="اسم الطالب" ' +
               'style="min-width:140px" aria-label="اسم الطالب">' +
        '<input id="newUser" type="text" class="code" inputmode="numeric" maxlength="4" ' +
               'placeholder="رقم المستخدم" style="max-width:130px" ' +
               'aria-label="رقم المستخدم (اختياري)">' +
        '<input id="newSecret" type="text" class="code" inputmode="numeric" maxlength="4" ' +
               'placeholder="الرقم السري" style="max-width:130px" ' +
               'aria-label="الرقم السري (اختياري)">' +
        '<button class="btn mint" type="submit">إضافة</button>' +
      "</form>" +
      '<p class="muted small" style="margin:-10px 0 16px">' +
        "اتركي الخانتين فارغتين ليولّد التطبيق رقمين تلقائيًا. " +
        "الرقمان يظهران لكِ وحدك في هذه اللوحة.</p>" +

      (students.length ?
        '<div class="student-grid">' + students.map(function (s) {
          var t = tier(s.averageRate);
          return '<button class="student-card" data-sid="' + s.id + '">' +
            '<div class="nm" style="margin-bottom:6px">' + esc(s.name) + "</div>" +
            '<div class="row" style="gap:6px;margin-bottom:8px">' +
              '<span class="code-tag">👤 ' + esc(s.username) + "</span>" +
              '<span class="code-tag secret">🔑 ' + esc(s.secret) + "</span>" +
            "</div>" +
            '<div class="row" style="gap:7px">' +
              '<span class="badge ' + (t === "none" ? "" : t) + '">' +
                (s.averageRate === null ? "—" : s.averageRate + "٪") + "</span>" +
              '<span class="chip">' + s.masteredCount + "/" + s.totalCategories + " مُتقن</span>" +
            "</div>" +
            (s.trophies && s.trophies.length ?
              '<div class="row" style="gap:3px;margin-top:8px">' +
                s.trophies.map(function (k) { return trophy(k, 26); }).join("") +
              "</div>" : "") +
            '<p class="small muted" style="margin:8px 0 0">' +
              (s.diagnosticDone
                ? lastSeenText(s.lastSeen) + " · " +
                  Math.min(s.weekly.done, s.weekly.goal) + "/" + s.weekly.goal +
                  " هذا الأسبوع"
                : "لم يُكمل التشخيص بعد") +
            "</p></button>";
        }).join("") + "</div>" :
        '<p class="muted">أضيفي أسماء طلابك أعلاه، ثم أعطي كل طالب رقمه ' +
        "ليدخل به من أي جهاز.</p>") +
    "</div>" +

    (weakest ?
      '<div class="card">' +
        "<h2>ركّزي شرحك القادم هنا</h2>" +
        '<p>أضعف موضوع في الصف كله هو <b>' + esc(catLabel(weakest.category)) +
          "</b> بمتوسط <b>" + weakest.rate + "٪</b>.</p>" +
        '<div class="rule-box"><span class="label">القاعدة العلاجية</span>' +
          esc(catRule(weakest.category)) + "</div>" +
      "</div>" : "") +

    '<div class="card">' +
      "<h2>متوسط الصف لكل موضوع</h2>" +
      '<p class="muted small" style="margin-top:-6px">من الأضعف إلى الأقوى</p>' +
      '<div class="mastery">' + averages.map(function (a) {
        return masteryRow({ category: a.category, rate: a.rate,
                            attempts: a.attempts, correct: a.correct,
                            mastered: false });
      }).join("") + "</div>" +
    "</div>"
  );

  on("logout", "click", function () {
    api("/api/logout", { method: "POST" }).then(function () {
      S.session = null;
      screenLogin();
    });
  });

  ["newUser", "newSecret"].forEach(function (id) {
    el(id).addEventListener("input", function (e) {
      e.target.value = e.target.value.replace(/\D/g, "").slice(0, 4);
    });
  });

  el("addForm").addEventListener("submit", function (e) {
    e.preventDefault();
    var btn = e.target.querySelector("button[type=submit]");
    btn.disabled = true;
    api("/api/teacher/students", {
      method: "POST",
      body: { name: el("newName").value, username: el("newUser").value,
              secret: el("newSecret").value }
    }).then(function (res) {
      toast("أُضيف " + res.student.name + " — المستخدم " + res.student.username +
            " والسري " + res.student.secret, 8000);
      screenTeacherDashboard();
    }).catch(function (err) {
      btn.disabled = false;
      toast(err.message, 5000);
    });
  });

  Array.prototype.forEach.call(App.querySelectorAll("[data-sid]"), function (b) {
    b.addEventListener("click", function () { screenTeacherStudent(b.dataset.sid); });
  });
}

/* الخطة العلاجية: مشتقّة من أداء الطالب، لا مكتوبة يدويًا */
function planCard(plan) {
  var KIND = {
    focus:    { label: "نقطة ضعف — تدريب مركّز", cls: "low" },
    watch:    { label: "متذبذبة — متابعة", cls: "mid" },
    maintain: { label: "نقطة قوة — مراجعة متباعدة", cls: "good" }
  };
  return '<div class="card">' +
    "<h2>الخطة العلاجية</h2>" +
    '<p style="margin-top:-4px"><b>' + esc(plan.headline) + "</b></p>" +
    '<div class="stack" style="margin-top:14px">' +
      plan.steps.map(function (st) {
        var k = KIND[st.kind] || KIND.watch;
        return '<div class="plan-step ' + k.cls + '">' +
          '<div class="between" style="margin-bottom:4px">' +
            '<span style="font-weight:800">' + esc(st.label) + "</span>" +
            '<span class="badge ' + k.cls + '">' +
              (st.rate === null ? "—" : st.rate + "٪") + "</span>" +
          "</div>" +
          '<p class="small" style="margin:0 0 6px;opacity:.75">' + esc(k.label) + "</p>" +
          '<p class="small" style="margin:0">' + esc(st.action) + "</p>" +
          (st.target ? '<p class="small" style="margin:6px 0 0;font-weight:700">' +
                       esc(st.target) + "</p>" : "") +
          (st.kind === "focus" && st.rule
            ? '<div class="rule-box" style="margin-top:10px">' +
              '<span class="label">القاعدة التي تُذكّرينه بها</span>' +
              esc(st.rule) + "</div>" : "") +
        "</div>";
      }).join("") +
    "</div>" +
  "</div>";
}

function screenTeacherStudent(sid) {
  render('<div class="card center"><div class="spinner"></div></div>');
  api("/api/teacher/student/" + encodeURIComponent(sid)).then(function (data) {
    var st = data.student;
    var mastery = data.mastery;
    var mastered = mastery.filter(function (m) { return m.mastered; }).length;

    render(
      '<div class="between" style="margin-bottom:18px">' +
        "<div><h1 style=\"margin:0\">" + esc(st.name) + "</h1>" +
        '<p class="muted small" style="margin:2px 0 0">' +
          (st.diagnosticDone ? "أكمل التشخيص · " + lastSeenText(st.lastSeen)
                             : "لم يُكمل التشخيص بعد") + "</p></div>" +
        '<button class="btn ghost sm" id="back">→ الصف</button>' +
      "</div>" +

      '<div class="card" style="background:var(--sun)">' +
        '<p class="small center" style="margin:0 0 10px">' +
          "بيانات دخوله — تظهر لكِ وحدك</p>" +
        '<div class="row" style="justify-content:center;gap:26px">' +
          '<div class="center"><p class="small" style="margin:0">رقم المستخدم</p>' +
            '<div class="display" style="font-size:2.1rem;letter-spacing:.24em">' +
              esc(st.username) + "</div></div>" +
          '<div class="center"><p class="small" style="margin:0">الرقم السري</p>' +
            '<div class="display" style="font-size:2.1rem;letter-spacing:.24em">' +
              esc(st.secret) + "</div></div>" +
        "</div>" +
      "</div>" +

      (data.trophies ?
        '<div class="card">' +
          '<div class="between" style="margin-bottom:10px">' +
            "<h3 style=\"margin:0\">إنجازاته</h3>" +
            '<span class="chip">' + data.trophies.sessionsDone + " تدريبًا</span>" +
          "</div>" +
          '<div class="row" style="gap:10px;align-items:center">' +
            (data.trophies.earned.length
              ? data.trophies.earned.map(function (k) { return trophy(k, 44); }).join("")
              : '<span class="muted small">لم يحصل على كأس بعد</span>') +
            '<span class="chip" style="margin-inline-start:auto">مهمة الأسبوع: ' +
              Math.min(data.weekly.done, data.weekly.goal) + "/" +
              data.weekly.goal + "</span>" +
          "</div>" +
        "</div>" : "") +

      (data.plan ? planCard(data.plan) : "") +

      '<div class="card">' +
        '<div class="between" style="margin-bottom:16px">' +
          "<h2 style=\"margin:0\">خريطة الإتقان</h2>" +
          '<span class="chip">' + mastered + " من " + mastery.length + " مُتقن</span>" +
        "</div>" +
        '<div class="mastery">' + mastery.map(masteryRow).join("") + "</div>" +
      "</div>" +

      (mastery[0] && mastery[0].rate !== null ?
        '<div class="card"><h3>القاعدة التي يحتاجها أكثر</h3>' +
          '<div class="rule-box"><span class="label">' +
          esc(catLabel(mastery[0].category)) + "</span>" +
          esc(catRule(mastery[0].category)) + "</div></div>" : "") +

      '<div class="card stack">' +
        "<h3 style=\"margin:0\">إدارة</h3>" +
        '<button class="btn sky block sm" id="doRename">تغيير الاسم</button>' +
        '<button class="btn sky block sm" id="doUser">تغيير رقم المستخدم</button>' +
        '<button class="btn sky block sm" id="doSecret">تغيير الرقم السري</button>' +
        '<button class="btn block sm" id="doReset">مسح تقدّمه والبدء من جديد</button>' +
        '<button class="btn warn block sm" id="doDelete">حذفه من القائمة</button>' +
      "</div>"
    );

    on("back", "click", screenTeacherDashboard);

    function act(path, body, okMsg, reload) {
      api("/api/teacher/student/" + encodeURIComponent(sid) + path,
          { method: "POST", body: body })
        .then(function () {
          toast(okMsg);
          if (reload === "class") screenTeacherDashboard();
          else screenTeacherStudent(sid);
        })
        .catch(function (e) { toast(e.message, 5000); });
    }

    on("doRename", "click", function () {
      var name = prompt("الاسم الجديد:", st.name);
      if (name) act("/rename", { name: name }, "تم تغيير الاسم");
    });

    on("doUser", "click", function () {
      var u = prompt("رقم المستخدم الجديد (٤ أرقام):", st.username);
      if (u) act("/credentials", { username: u }, "تم تغيير رقم المستخدم");
    });

    on("doSecret", "click", function () {
      var v = prompt("الرقم السري الجديد (٤ أرقام):", st.secret);
      if (v) act("/credentials", { secret: v }, "تم تغيير الرقم السري");
    });

    on("doReset", "click", function () {
      if (!confirm("سيُمسح كل تقدّم " + st.name + " ويعيد الاختبار التشخيصي من جديد. متأكدة؟")) return;
      act("/reset", {}, "مُسح التقدّم");
    });

    on("doDelete", "click", function () {
      if (!confirm("سيُحذف " + st.name + " وكل بياناته نهائيًا. متأكدة؟")) return;
      act("/delete", {}, "حُذف الطالب", "class");
    });

  }).catch(function (e) {
    toast(e.message);
    screenTeacherDashboard();
  });
}

/* ═══════════════ الإقلاع ═══════════════ */

function boot() {
  // المتصفح يستعيد موضع التمرير بعد إعادة التحميل، فتظهر الشاشة الجديدة
  // مقصوصة من أعلى. التطبيق يعيد رسم شاشته من البداية دائمًا، فنمنع ذلك.
  if ("scrollRestoration" in history) history.scrollRestoration = "manual";
  window.scrollTo(0, 0);
  plantGarden();
  api("/api/bootstrap").then(function (data) {
    S.categories = data.categories;
    S.paragraphs = data.paragraphs;
    S.neuralTts = data.neuralTts;
    S.visionGrading = data.visionGrading;
    S.catBy = {};
    data.categories.forEach(function (c) { S.catBy[c.key] = c; });

    S.session = data.session || null;
    if (!S.session) return screenLogin();
    if (S.session.role === "teacher") return screenTeacherDashboard();
    // الاختبار التشخيصي إلزامي قبل أي شاشة أخرى.
    if (!S.session.student.diagnosticDone) return screenDiagnosticIntro();
    screenDashboard();
  }).catch(function () {
    render('<div class="card center"><h2>تعذّر الاتصال بالخادم</h2>' +
           '<p class="muted">تأكد أن الخادم يعمل، ثم أعد تحميل الصفحة.</p></div>');
  });
}

boot();
